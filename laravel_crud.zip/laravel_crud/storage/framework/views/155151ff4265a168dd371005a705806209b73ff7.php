<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Crud</h1>

    <div class="text-center">
        <a href="<?php echo e(route('motorista_view')); ?>">
        <button class="btn btn-success">Cadastrar</button>
        </a>
    </div>

    <div class ="col-8 m-auto">
    <table class="table text-center">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nome</th>
      <th scope="col">CPF</th>
      <th scope="col">CNH</th>
      <th scope="col">Ações</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $motorista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motoristas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($motoristas->id); ?></th>
      <td><?php echo e($motoristas->name); ?></td>
      <td><?php echo e($motoristas->cpf); ?></td>
      <td><?php echo e($motoristas->cnh); ?></td>
      <td>
        <a href="<?php echo e(route('editar_motorista',['id'=>$motoristas->id])); ?>">
           <button class="btn btn-primary">Editar</button>
        </a>

        <a href="<?php echo e(route('apagar_motorista',['id'=>$motoristas->id])); ?>">
           <button class="btn btn-danger">Apagar</button>
        </a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_crud\resources\views/index.blade.php ENDPATH**/ ?>