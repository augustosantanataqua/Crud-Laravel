<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Excluir Motorista</title>
</head>
<body>
    <form action="<?php echo e(route('excluir_motorista', ['id' => $motorista->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">Deseja mesmo excluir esse motorista ?$_COOKIE</label><br>
        <input type="text" name="name" placeholder="Nome:" value="<?php echo e($motorista->name); ?>"><br>
        <button>Sim</button>
        <!-- <?php echo e(route('alterar_motorista', ['id' => $motorista->id])); ?> -->
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel_crud\resources\views/delete.blade.php ENDPATH**/ ?>