<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Editar</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>
    <form action="<?php echo e(route('alterar_motorista', ['id' => $motorista->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Nome:" value="<?php echo e($motorista->name); ?>"><br>
        <input type="text" name="cpf" placeholder="CPF:" value="<?php echo e($motorista->cpf); ?>"><br>
        <input type="text" name="cnh" placeholder="CNH:" value="<?php echo e($motorista->cnh); ?>"><br>
        <button>Editar</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel_crud\resources\views/edit.blade.php ENDPATH**/ ?>