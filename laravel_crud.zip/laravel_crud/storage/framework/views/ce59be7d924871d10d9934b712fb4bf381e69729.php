<?php $__env->startSection('content'); ?>
<h1 class="text-center">Cadastrar</h1>

<div class="col-8 m-auto">
    <form name="formCad" id="formCad" method="post" action="<?php echo e(route('cadastrar_motorista')); ?>">
        <?php echo csrf_field(); ?>
        <input class="form-control" type="text" name="name" id="name" placeholder="Nome:" required><br>
        <input class="form-control" type="text" name="cpf" id="cpf" placeholder="CPF:" required><br>
        <input class="form-control" type="text" name="cnh" id="cnh" placeholder="CNH:" required><br>
        <input class="btn btn-primary" type="submit" value="Cadastrar">
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_crud\resources\views/create.blade.php ENDPATH**/ ?>